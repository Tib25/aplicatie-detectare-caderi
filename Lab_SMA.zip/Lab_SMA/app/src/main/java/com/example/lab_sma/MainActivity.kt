package com.example.lab_sma // Păstrează pachetul corect al proiectului tău

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TodoScreen()
                }
            }
        }
    }
}

// 1. Modelul de date
data class TodoItem(val id: Int, val task: String, val isDone: Boolean = false)

// 2. ViewModel - Logica de business (CRUD)
class TodoViewModel : ViewModel() {
    private val _todos = mutableStateListOf<TodoItem>()
    val todos: List<TodoItem> get() = _todos
    private var nextId = 1

    fun addTodo(task: String) {
        if (task.isNotBlank()) {
            _todos.add(TodoItem(id = nextId++, task = task))
        }
    }

    fun toggleTodo(id: Int) {
        val index = _todos.indexOfFirst { it.id == id }
        if (index != -1) {
            _todos[index] = _todos[index].copy(isDone = !_todos[index].isDone)
        }
    }

    fun deleteTodo(id: Int) {
        _todos.removeAll { it.id == id }
    }
}

// 3. Interfața utilizatorului (UI)
@Composable
fun TodoScreen(viewModel: TodoViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var newTaskText by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newTaskText,
                onValueChange = { newTaskText = it },
                label = { Text("Adaugă un task") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                viewModel.addTodo(newTaskText)
                newTaskText = ""
            }) {
                Text("Adaugă")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(viewModel.todos) { todo ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = todo.isDone,
                        onCheckedChange = { viewModel.toggleTodo(todo.id) }
                    )

                    Text(
                        text = todo.task,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { viewModel.deleteTodo(todo.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Șterge")
                    }
                }
            }
        }
    }
}